# week-online-business-card
week 5 Assignment : online Business card (HTML &amp; CSS ) with google Doc shortcut keys 
##google shortcut keys : https://docs.google.com/document/d/14JcSBjCh4XcmfOA5yQiHT64TgWAA5TCe-l_8Xg7FtWg/edit?tab=t.0 
